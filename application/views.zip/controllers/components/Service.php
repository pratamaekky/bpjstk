<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'controllers/api/v60/Masters.php';
include_once(APPPATH . "controllers/base/Transformer.php");

class Service
{
    protected $CI;
    protected $appSrc;

    public function __construct($command, $flag, $params)
    {
        $this->Masters = new Masters();
        $this->CI = &get_instance();
        $this->CI->load->helper(array());
        $this->CI->load->model(array());
        $this->CI->load->library(array(
            'form_validation'
        ));

        $this->_command = $command;
        $this->_flag = $flag;
        $this->_params = $params;
    }

    private function _lists()
    {
        $responseProvince = $this->Masters->data("province");
        $responseProvince = json_decode($responseProvince);

        $responseHospitalType = $this->Masters->data("general", "hospital_type");
        $responseHospitalType = json_decode($responseHospitalType);

        $responseHospitalOwner = $this->Masters->data("general", "hospital_owner");
        $responseHospitalOwner = json_decode($responseHospitalOwner);

        $data["getProvince"] = ($responseProvince->result == 200) ? $responseProvince->data->item : $responseProvince->data;
        $data["getHospitalType"] = ($responseHospitalType->result == 200) ? $responseHospitalType->data->item : $responseHospitalType->data;
        $data["getHospitalOwner"] = ($responseHospitalOwner->result == 200) ? $responseHospitalOwner->data->item : $responseHospitalOwner->data;

        $this->CI->load->view("public/service/lists.php", $data);
    }

    private function _data()
    {
        $items = [];
        $draw = 1;
        $totalRecods = 0;
        $totalDisplays = 0;
        $responseHospital = $this->Masters->data("hospital", null, $this->_params);
        $responseHospital = json_decode($responseHospital);

        if ($responseHospital->result == 200) {
            $resHospital = $responseHospital->data->item->aaData;

            if (!empty($resHospital)) {
                foreach ($resHospital as $key => $hospital) {
                    $row = [
                        "no" => ($key  + 1),
                        "name" => $hospital->name,
                        "room" => "<a class='btn btn-block btn-primary' href='" . base_url("master/service/room/lists/$hospital->id") . "' aria-expanded='true'><i class='far fa-eye mr-2'></i> Kamar</a>",
                        "radiology" => "<a class='btn btn-block btn-secondary' href='" . base_url("master/service/radiology/lists/$hospital->id") . "' aria-expanded='true'><i class='far fa-eye mr-2'></i> Radiologi</a>",
                        "medic" => "<a class='btn btn-block btn-danger' href='" . base_url("master/service/medic/lists/$hospital->id") . "' aria-expanded='true'><i class='far fa-eye mr-2'></i> Medikal</a>",
                        "laboratory" => "<a class='btn btn-block btn-info' href='" . base_url("master/service/laboratory/lists/$hospital->id") . "' aria-expanded='true'><i class='far fa-eye mr-2'></i> Laboratorium</a>",
                        "doctor" => "<a class='btn btn-block btn-success' href='" . base_url("master/service/doctor/lists/$hospital->id") . "' aria-expanded='true'><i class='far fa-eye mr-2'></i> Dokter</a>",
                        "rehabilitation" => "<a class='btn btn-block btn-success' href='" . base_url("master/service/rehabilitation/lists/$hospital->id") . "' aria-expanded='true' style='background-color: #a52a2a;'><i class='far fa-eye mr-2'></i> Rehabilitasi</a>",
                        "fee" => "<a class='btn btn-block btn-warning' href='" . base_url("master/service/fee/lists/$hospital->id") . "' aria-expanded='true'><i class='far fa-eye mr-2'></i> Biaya</a>"
                    ];

                    $items[] = $row;
                }

                $draw = $responseHospital->data->item->draw;
                $totalRecods = $responseHospital->data->item->iTotalRecords;
                $totalDisplays = $responseHospital->data->item->iTotalDisplayRecords;
            }
        }

        $result = [
            "draw" => $draw,
            "recordsTotal" => $totalRecods,
            "recordsFiltered" => $totalDisplays,
            "data" => $items
        ];

        echo json_encode($result);
    }

    private function _room()
    {
        if (!is_null($this->_flag) && $this->_flag == "lists") {
            $rsId = $this->CI->uri->segment(5);
            if (!is_null($rsId)) {
                $data["rsId"] = $rsId;
                $hospital = $this->Masters->data("hospital", "detail", ["rsId" => $rsId]);
                $hospital = json_decode($hospital);
                $data["hospital"] = ($hospital->result == 200) ? $hospital->data->item : null;
                $this->CI->load->view("public/service/room.php", $data);
            } else {
                $this->CI->load->view("public/service/lists.php", []);
            }
        } else if (!is_null($this->_flag) && $this->_flag == "data") {
            $items = [];
            $draw = 1;
            $totalRecods = 0;
            $totalDisplays = 0;
            $responseRoom = $this->Masters->data("room", null, $this->_params);
            $responseRoom = json_decode($responseRoom);

            if ($responseRoom->result == 200) {
                $resRoom = $responseRoom->data->item->aaData;

                if (!empty($resRoom)) {
                    foreach ($resRoom as $key => $room) {
                        $row = [
                            "no" => ($key  + 1),
                            "value" => $room->value,
                            "fare" => "Rp " . number_format($room->fare, 0, ",",".")
                        ];

                        $items[] = $row;
                    }

                    $draw = $responseRoom->data->item->draw;
                    $totalRecods = $responseRoom->data->item->iTotalRecords;
                    $totalDisplays = $responseRoom->data->item->iTotalDisplayRecords;
                }
            }

            $result = [
                "draw" => $draw,
                "recordsTotal" => $totalRecods,
                "recordsFiltered" => $totalDisplays,
                "data" => $items
            ];

            echo json_encode($result);
        } else if (!is_null($this->_flag) && $this->_flag == "save") {
            unset($this->_params["todo"]);
            unset($this->_params["btnTodo"]);
            $saveHospital = $this->Masters->save("room", $this->_params);

            echo $saveHospital;
        }
    }

    private function _radiology()
    {
        if (!is_null($this->_flag) && $this->_flag == "lists") {
            $rsId = $this->CI->uri->segment(5);
            if (!is_null($rsId)) {
                $data["rsId"] = $rsId;
                $hospital = $this->Masters->data("hospital", "detail", ["rsId" => $rsId]);
                $hospital = json_decode($hospital);
                $data["hospital"] = ($hospital->result == 200) ? $hospital->data->item : null;
                $this->CI->load->view("public/service/radiology.php", $data);
            } else {
                $this->CI->load->view("public/service/lists.php", []);
            }
        } else if (!is_null($this->_flag) && $this->_flag == "data") {
            $items = [];
            $draw = 1;
            $totalRecods = 0;
            $totalDisplays = 0;
            $responseRoom = $this->Masters->data("radiology", null, $this->_params);
            $responseRoom = json_decode($responseRoom);

            if ($responseRoom->result == 200) {
                $resRoom = $responseRoom->data->item->aaData;

                if (!empty($resRoom)) {
                    foreach ($resRoom as $key => $room) {
                        $row = [
                            "no" => ($key  + 1),
                            "value" => $room->value,
                            "fare" => "Rp " . number_format($room->fare, 0, ",",".")
                        ];

                        $items[] = $row;
                    }

                    $draw = $responseRoom->data->item->draw;
                    $totalRecods = $responseRoom->data->item->iTotalRecords;
                    $totalDisplays = $responseRoom->data->item->iTotalDisplayRecords;
                }
            }

            $result = [
                "draw" => $draw,
                "recordsTotal" => $totalRecods,
                "recordsFiltered" => $totalDisplays,
                "data" => $items
            ];

            echo json_encode($result);
        } else if (!is_null($this->_flag) && $this->_flag == "save") {
            unset($this->_params["todo"]);
            unset($this->_params["btnTodo"]);
            $saveHospital = $this->Masters->save("radiology", $this->_params);

            echo $saveHospital;
        }
    }

    private function _rehabilitation()
    {
        if (!is_null($this->_flag) && $this->_flag == "lists") {
            $rsId = $this->CI->uri->segment(5);
            if (!is_null($rsId)) {
                $data["rsId"] = $rsId;
                $hospital = $this->Masters->data("hospital", "detail", ["rsId" => $rsId]);
                $hospital = json_decode($hospital);
                $data["hospital"] = ($hospital->result == 200) ? $hospital->data->item : null;
                $this->CI->load->view("public/service/rehabilitation.php", $data);
            } else {
                $this->CI->load->view("public/service/lists.php", []);
            }
        } else if (!is_null($this->_flag) && $this->_flag == "data") {
            $items = [];
            $draw = 1;
            $totalRecods = 0;
            $totalDisplays = 0;
            $responseRehabilitation = $this->Masters->data("rehabilitation", null, $this->_params);
            $responseRehabilitation = json_decode($responseRehabilitation);

            if ($responseRehabilitation->result == 200) {
                $resRehabilitation = $responseRehabilitation->data->item->aaData;

                if (!empty($resRehabilitation)) {
                    foreach ($resRehabilitation as $key => $rehab) {
                        $row = [
                            "no" => ($key  + 1),
                            "value" => $rehab->value,
                            "fare" => "Rp " . number_format($rehab->fare, 0, ",",".")
                        ];

                        $items[] = $row;
                    }

                    $draw = $responseRehabilitation->data->item->draw;
                    $totalRecods = $responseRehabilitation->data->item->iTotalRecords;
                    $totalDisplays = $responseRehabilitation->data->item->iTotalDisplayRecords;
                }
            }

            $result = [
                "draw" => $draw,
                "recordsTotal" => $totalRecods,
                "recordsFiltered" => $totalDisplays,
                "data" => $items
            ];

            echo json_encode($result);
        } else if (!is_null($this->_flag) && $this->_flag == "save") {
            unset($this->_params["todo"]);
            unset($this->_params["btnTodo"]);
            $saveHospital = $this->Masters->save("rehabilitation", $this->_params);

            echo $saveHospital;
        }
    }

    private function _medic()
    {
        if (!is_null($this->_flag) && $this->_flag == "lists") {
            $rsId = $this->CI->uri->segment(5);
            if (!is_null($rsId)) {
                $data["rsId"] = $rsId;
                $hospital = $this->Masters->data("hospital", "detail", ["rsId" => $rsId]);
                $hospital = json_decode($hospital);
                $data["hospital"] = ($hospital->result == 200) ? $hospital->data->item : null;
                $this->CI->load->view("public/service/medic.php", $data);
            } else {
                $this->CI->load->view("public/service/lists.php", []);
            }
        } else if (!is_null($this->_flag) && $this->_flag == "data") {
            $items = [];
            $draw = 1;
            $totalRecods = 0;
            $totalDisplays = 0;
            $responseMedic = $this->Masters->data("medic", null, $this->_params);
            $responseMedic = json_decode($responseMedic);

            if ($responseMedic->result == 200) {
                $resMedic = $responseMedic->data->item->aaData;

                if (!empty($resMedic)) {
                    foreach ($resMedic as $key => $medic) {
                        $row = [
                            "no" => ($key  + 1),
                            "value" => $medic->value,
                            "fare" => "Rp " . number_format($medic->fare, 0, ",",".")
                        ];

                        $items[] = $row;
                    }

                    $draw = $responseMedic->data->item->draw;
                    $totalRecods = $responseMedic->data->item->iTotalRecords;
                    $totalDisplays = $responseMedic->data->item->iTotalDisplayRecords;
                }
            }

            $result = [
                "draw" => $draw,
                "recordsTotal" => $totalRecods,
                "recordsFiltered" => $totalDisplays,
                "data" => $items
            ];

            echo json_encode($result);
        } else if (!is_null($this->_flag) && $this->_flag == "save") {
            unset($this->_params["todo"]);
            unset($this->_params["btnTodo"]);
            $saveHospital = $this->Masters->save("medic", $this->_params);

            echo $saveHospital;
        }
    }

    private function _doctor()
    {
        if (!is_null($this->_flag) && $this->_flag == "lists") {
            $rsId = $this->CI->uri->segment(5);
            if (!is_null($rsId)) {
                $data["rsId"] = $rsId;
                $hospital = $this->Masters->data("hospital", "detail", ["rsId" => $rsId]);
                $hospital = json_decode($hospital);

                $responseDoctorSpecialist = $this->Masters->data("general", "doctor_specialist");
                $responseDoctorSpecialist = json_decode($responseDoctorSpecialist);

                $data["doctorSpecialist"] = ($responseDoctorSpecialist->result == 200) ? $responseDoctorSpecialist->data->item : $responseDoctorSpecialist->data;
                $data["hospital"] = ($hospital->result == 200) ? $hospital->data->item : null;
                $this->CI->load->view("public/service/doctor.php", $data);
            } else {
                $this->CI->load->view("public/service/lists.php", []);
            }
        } else if (!is_null($this->_flag) && $this->_flag == "data") {
            $items = [];
            $draw = 1;
            $totalRecods = 0;
            $totalDisplays = 0;
            $responseDoctor = $this->Masters->data("doctor", null, $this->_params);
            $responseDoctor = json_decode($responseDoctor);

            if ($responseDoctor->result == 200) {
                $resDoctor = $responseDoctor->data->item->aaData;

                if (!empty($resDoctor)) {
                    foreach ($resDoctor as $key => $doctor) {
                        $row = [
                            "no" => ($key  + 1),
                            "name" => $doctor->name,
                            "doctor_specialist" => $doctor->doctor_specialist,
                            "fare" => "Rp " . number_format($doctor->fare, 0, ",",".")
                        ];

                        $items[] = $row;
                    }

                    $draw = $responseDoctor->data->item->draw;
                    $totalRecods = $responseDoctor->data->item->iTotalRecords;
                    $totalDisplays = $responseDoctor->data->item->iTotalDisplayRecords;
                }
            }

            $result = [
                "draw" => $draw,
                "recordsTotal" => $totalRecods,
                "recordsFiltered" => $totalDisplays,
                "data" => $items
            ];

            echo json_encode($result);
        } else if (!is_null($this->_flag) && $this->_flag == "save") {
            unset($this->_params["todo"]);
            unset($this->_params["btnTodo"]);
            $saveDoctor = $this->Masters->save("doctor", $this->_params);

            echo $saveDoctor;
        }
    }

    private function _laboratory()
    {
        if (!is_null($this->_flag) && $this->_flag == "lists") {
            $rsId = $this->CI->uri->segment(5);
            if (!is_null($rsId)) {
                $data["rsId"] = $rsId;
                $hospital = $this->Masters->data("hospital", "detail", ["rsId" => $rsId]);
                $hospital = json_decode($hospital);

                $responseLabCategory = $this->Masters->data("general", "lab_category");
                $responseLabCategory = json_decode($responseLabCategory);

                $data["labCategory"] = ($responseLabCategory->result == 200) ? $responseLabCategory->data->item : $responseLabCategory->data;
                $data["hospital"] = ($hospital->result == 200) ? $hospital->data->item : null;
                $this->CI->load->view("public/service/laboratory.php", $data);
            } else {
                $this->CI->load->view("public/service/lists.php", []);
            }
        } else if (!is_null($this->_flag) && $this->_flag == "data") {
            $items = [];
            $draw = 1;
            $totalRecods = 0;
            $totalDisplays = 0;
            $responseLaboratory = $this->Masters->data("laboratory", null, $this->_params);
            $responseLaboratory = json_decode($responseLaboratory);

            if ($responseLaboratory->result == 200) {
                $resLaboratory = $responseLaboratory->data->item->aaData;

                if (!empty($resLaboratory)) {
                    foreach ($resLaboratory as $key => $lab) {
                        $row = [
                            "no" => ($key  + 1),
                            "name" => $lab->name,
                            "lab_category" => $lab->lab_category,
                            "fare" => "Rp " . number_format($lab->fare, 0, ",",".")
                        ];

                        $items[] = $row;
                    }

                    $draw = $responseLaboratory->data->item->draw;
                    $totalRecods = $responseLaboratory->data->item->iTotalRecords;
                    $totalDisplays = $responseLaboratory->data->item->iTotalDisplayRecords;
                }
            }

            $result = [
                "draw" => $draw,
                "recordsTotal" => $totalRecods,
                "recordsFiltered" => $totalDisplays,
                "data" => $items
            ];

            echo json_encode($result);
        } else if (!is_null($this->_flag) && $this->_flag == "save") {
            unset($this->_params["todo"]);
            unset($this->_params["btnTodo"]);
            $saveLaboratory = $this->Masters->save("laboratory", $this->_params);

            echo $saveLaboratory;
        }
    }

    private function _fee()
    {
        if (!is_null($this->_flag) && $this->_flag == "lists") {
            $rsId = $this->CI->uri->segment(5);
            if (!is_null($rsId)) {
                $data["rsId"] = $rsId;
                $hospital = $this->Masters->data("hospital", "detail", ["rsId" => $rsId]);
                $hospital = json_decode($hospital);

                $responseFee = $this->Masters->data("general", "other_fee");
                $responseFee = json_decode($responseFee);

                $data["otherFee"] = ($responseFee->result == 200) ? $responseFee->data->item : $responseFee->data;
                $data["hospital"] = ($hospital->result == 200) ? $hospital->data->item : null;
                $this->CI->load->view("public/service/fee.php", $data);
            } else {
                $this->CI->load->view("public/service/lists.php", []);
            }
        } else if (!is_null($this->_flag) && $this->_flag == "data") {
            $items = [];
            $draw = 1;
            $totalRecods = 0;
            $totalDisplays = 0;
            $responseFee = $this->Masters->data("fee", null, $this->_params);
            $responseFee = json_decode($responseFee);

            if ($responseFee->result == 200) {
                $resFee = $responseFee->data->item->aaData;

                if (!empty($resFee)) {
                    foreach ($resFee as $key => $lab) {
                        $row = [
                            "no" => ($key  + 1),
                            "name" => $lab->name,
                            "other_fee" => $lab->other_fee,
                            "fare" => "Rp " . number_format($lab->fare, 0, ",",".")
                        ];

                        $items[] = $row;
                    }

                    $draw = $responseFee->data->item->draw;
                    $totalRecods = $responseFee->data->item->iTotalRecords;
                    $totalDisplays = $responseFee->data->item->iTotalDisplayRecords;
                }
            }

            $result = [
                "draw" => $draw,
                "recordsTotal" => $totalRecods,
                "recordsFiltered" => $totalDisplays,
                "data" => $items
            ];

            echo json_encode($result);
        } else if (!is_null($this->_flag) && $this->_flag == "save") {
            unset($this->_params["todo"]);
            unset($this->_params["btnTodo"]);
            $saveFee = $this->Masters->save("fee", $this->_params);

            echo $saveFee;
        }
    }

    public function action()
    {
        switch ($this->_command) {
            case 'lists':
                $this->_lists();
                break;
            case 'data':
                $this->_data();
                break;
            case 'room':
                $this->_room();
                break;
            case 'radiology':
                $this->_radiology();
                break;
            case 'rehabilitation':
                $this->_rehabilitation();
                break;
            case 'medic':
                $this->_medic();
                break;
            case 'doctor':
                $this->_doctor();
                break;
            case 'laboratory':
                $this->_laboratory();
                break;
            case 'fee':
                $this->_fee();
                break;
        }
    }
}