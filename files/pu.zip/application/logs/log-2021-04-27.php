<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-27 00:21:22 --> 404 Page Not Found: /index
ERROR - 2021-04-27 02:24:02 --> 404 Page Not Found: lanang/Pages/widgets.html
