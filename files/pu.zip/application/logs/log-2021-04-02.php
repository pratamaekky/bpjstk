<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-02 00:07:42 --> Severity: Error --> Allowed memory size of 536870912 bytes exhausted (tried to allocate 4096 bytes) C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 818
ERROR - 2021-04-02 00:07:58 --> Severity: Error --> Allowed memory size of 536870912 bytes exhausted (tried to allocate 4096 bytes) C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 818
ERROR - 2021-04-02 00:08:02 --> Severity: Error --> Allowed memory size of 536870912 bytes exhausted (tried to allocate 33554440 bytes) C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 818
