<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-03-30 09:07:22 --> Severity: Notice --> Undefined index: attachment C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 739
ERROR - 2021-03-30 09:07:23 --> Severity: Notice --> Undefined index: created C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 740
ERROR - 2021-03-30 09:48:24 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:24 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:48:24 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:24 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:48:24 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:24 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:48:40 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:40 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:48:40 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:40 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:48:40 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:40 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:48:43 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:43 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:48:43 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:43 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:48:43 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 716
ERROR - 2021-03-30 09:48:43 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:49:31 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:49:31 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 718
ERROR - 2021-03-30 09:49:31 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:49:31 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 718
ERROR - 2021-03-30 09:49:31 --> Severity: Warning --> Illegal string offset 'attachment' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 717
ERROR - 2021-03-30 09:49:31 --> Severity: Warning --> Illegal string offset 'created' C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 718
