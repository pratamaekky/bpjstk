<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-05 11:54:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 72
ERROR - 2021-04-05 11:54:25 --> Severity: Warning --> rename(./files/json/inv/index.json,./files/json/0/inv/index.json): The system cannot find the file specified. (code: 2) C:\xampp\htdocs\crew\fs\application\controllers\Grouping.php 79
ERROR - 2021-04-05 17:35:56 --> Severity: Notice --> Undefined property: Gets::$myutils C:\xampp\htdocs\crew\fs\application\controllers\Gets.php 74
ERROR - 2021-04-05 17:35:57 --> Severity: error --> Exception: Call to a member function writeApiLogs() on null C:\xampp\htdocs\crew\fs\application\controllers\Gets.php 74
ERROR - 2021-04-05 17:36:16 --> Severity: Notice --> Undefined property: Gets::$myutils C:\xampp\htdocs\crew\fs\application\controllers\Gets.php 74
ERROR - 2021-04-05 17:36:16 --> Severity: error --> Exception: Call to a member function writeApiLogs() on null C:\xampp\htdocs\crew\fs\application\controllers\Gets.php 74
